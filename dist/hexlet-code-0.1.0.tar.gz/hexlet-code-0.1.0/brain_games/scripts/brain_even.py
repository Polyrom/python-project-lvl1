#!/usr/bin/env python

from .games.even_game import run_brain_even


def main():
    run_brain_even()


if __name__ == "__main__":
    main()
