def sample_numbers(number_1, number_2):
    return f'{number_1} {number_2}'
