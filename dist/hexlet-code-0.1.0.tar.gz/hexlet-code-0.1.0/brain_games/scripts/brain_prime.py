#!/usr/bin/env python

from .games.engine import run_game


def main():
    run_game('prime')


if __name__ == "__main__":
    main()
