#!/usr/bin/env python

from .games.prime_game import run_brain_prime


def main():
    run_brain_prime()


if __name__ == "__main__":
    main()
