def is_even(number):
    if number % 2 == 0:
        return 'yes'
    else:
        return 'no'
