#!/usr/bin/env python

from games.gcd_game import run_brain_gcd


def main():
    run_brain_gcd()


if __name__ == "__main__":
    main()
