#!/usr/bin/env python

from games.engine import run_game


def main():
    run_game("gcd")


if __name__ == "__main__":
    main()
